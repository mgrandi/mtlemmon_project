
//
//  main.m
//  mtlemmon_project
//
//  Created by Mark Grandi on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MtlemmonAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MtlemmonAppDelegate class]));
    }
}
